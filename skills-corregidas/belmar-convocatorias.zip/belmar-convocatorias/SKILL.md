---
name: belmar-convocatorias
description: >
  Busca y estructura convocatorias, residencias, subvenciones y concursos audiovisuales para BELMAR (Lupe Belmonte), y devuelve las filas listas para añadir al Excel guía "BELMAR concursos / residencias / proyectos" en Google Drive. Usa esta skill SIEMPRE que Lupe mencione buscar residencias, convocatorias, subvenciones, concursos, ayudas, calls, open calls, becas o cualquier oportunidad audiovisual — incluso si solo dice "búscame cosas nuevas" o "actualiza el excel". También usar cuando pida explorar un tema concreto (p.ej. "busca residencias en Portugal" o "convocatorias para documentales en Europa") o cuando quiera saber si hay deadlines próximos en sus pestañas.
---

# BELMAR Convocatorias — Skill para Lupe Belmonte

## Contexto de la usuaria

**Quién es:** Lupe Belmonte, directora y productora audiovisual (BELMAR, Madrid). Trabaja en cine de autor, documental y experimental. Coproducción internacional frecuente.

**Proyectos activos (referencia para relevancia):**
- *Holding Heaven* — documental largo, España-Polonia, sobre Krzysztof Zanussi. Festivales objetivo: IDFA, Jihlava, Thessaloniki, Sheffield, Berlinale, Cannes (sec. doc).
- *Memorias de Barcelona 63* — documental corto, España. Festivales: Punto de Vista, DocumentaMadrid, Alcine, IDFA Shorts.
- *Elementos* — videopoema experimental, España-Túnez-Marruecos. Festivales: FIDMarseille, Punto de Vista, Marrakech IFF, Cairo IFF.
- *Busco tu rostro* — documental corto, Palestina-Israel-España. Festivales: DOK Leipzig, Hot Docs, IDFA, Visions du Réel.
- *Liberté* — documental corto, España, Mediterráneo. Festivales: Med Film Festival, Mostra Cine Mediterrani.
- *Albricias* — experimental corto, Argentina-España. Festivales: BAFICI, Mar del Plata, Visions du Réel, FIDMarseille.
- *AQUA* — ficción corto, España-Argentina (mentoría Sorrentino). Festivales: Clermont-Ferrand, Sundance Shorts, Locarno.

**Perfil de oportunidades que le interesan:**
- Residencias para directoras/cineastas (creación, desarrollo de guion, postproducción)
- Subvenciones y ayudas a producción/postproducción (ICAA, fondos europeos, AECID, regionales)
- Concursos de cortometraje (doc, experimental, ficción)
- Programas de pitching y desarrollo de proyectos
- Grants para cineastas (especialmente para mujeres o proyectos interculturales)
- Ámbito: España, Europa, Latinoamérica, internacional

---

## Estructura del Excel en Google Drive

El archivo se llama **"BELMAR concursos / residencias / proyectos"** y tiene varias pestañas. Las más relevantes para esta skill:

### Pestaña: Residencias / Convocatorias abiertas
Columnas (en orden):
`#` | `TÍTULO CONVOCATORIA` | `ORGANIZACIÓN / CUENTA IG` | `FECHA LÍMITE` | `TIPO` | `DURACIÓN` | `LUGAR` | `REQUISITOS / PERFIL` | `COSTE` | `NOTAS ADICIONALES` | `DESCRIPCIÓN BREVE` | `BENEFICIOS PRINCIPALES` | `ENLACE` | `ESTADO` | `APLICADO` | `PRIORIDAD`

### Pestaña: Concursos
Columnas (en orden):
`#` | `TÍTULO CONVOCATORIA` | `ORGANIZACIÓN / CUENTA IG` | `FECHA LÍMITE` | `FORMATO` | `GÉNEROS / CATEGORÍAS` | `ÁMBITO` | `PREMIOS / BENEFICIOS` | `ENLACE / CONTACTO` | `NOTAS ADICIONALES`

### Pestaña: Subvenciones / Ayudas
Columnas (en orden):
`#` | `TÍTULO CONVOCATORIA` | `ORGANIZACIÓN / CUENTA IG` | `FECHA LÍMITE` | `TIPO DE AYUDA` | `IMPORTE / BENEFICIO` | `REQUISITOS / PERFIL` | `ÁMBITO` | `ENLACE / CONTACTO` | `NOTAS ADICIONALES`

---

## Flujo de trabajo

### 1. Entender qué busca Lupe

Si la petición es vaga ("búscame cosas nuevas"), buscar en las tres categorías. Si especifica tipo o zona, enfocar ahí. Si menciona un proyecto concreto, buscar convocatorias que encajen con ese proyecto.

### 2. Buscar en internet

Usar `web_search` con queries variadas y específicas. Ejemplos de queries efectivas:
- `residencias artísticas cine 2026 convocatoria abierta`
- `open call filmmakers residency Europe 2026`
- `subvenciones cortometraje España 2026 ICAA`
- `concurso cortometraje documental experimental 2026`
- `grant women filmmakers 2026 open call`
- `residencia guion cinematográfico 2026`
- `pitching lab documentary 2026 call`

Buscar siempre con el año actual o próximo para evitar resultados caducados. Usar `web_fetch` para verificar fechas y detalles en las páginas oficiales cuando el snippet no sea suficiente.

### 3. Evaluar relevancia

Para cada resultado encontrado, valorar:
- ¿Está abierta o va a abrir próximamente?
- ¿Encaja con el perfil de Lupe (directora, documental/experimental/ficción, coproducción)?
- ¿Podría encajar con alguno de sus proyectos activos?
- ¿Ya está en el Excel? (si Lupe lo ha pasado antes, no duplicar)

**Criterios de prioridad:**
- **Alta:** Abierta, encaja directamente con un proyecto activo, beneficios relevantes (financiación, mentoría, visibilidad internacional)
- **Media:** Abierta pero encaje parcial, o cierra pronto con poco tiempo para preparar
- **Baja:** Aún no abierta (próxima edición), o encaje indirecto

### 4. Formatear la salida

Presentar los resultados en **dos formatos**:

**A) Resumen conversacional** — Una lista breve con los hallazgos más interesantes y por qué son relevantes para Lupe. Mencionar qué proyecto de los suyos podría beneficiarse.

**B) Filas para el Excel** — Una tabla en markdown por cada pestaña relevante, con todas las columnas rellenadas y listas para copiar/pegar. Usar `—` para campos desconocidos, nunca inventar datos.

Ejemplo de fila para pestaña Residencias:
```
| 12 | Nombre de la residencia | @cuenta_ig | 30 junio 2026 | Residencia creativa | 3 semanas | París, Francia | Directores con proyecto en desarrollo | Gratuita | Seleccionan 8 residentes | Programa de desarrollo para directores con primer largo en proceso | Alojamiento, mentoría, acceso a equipos | https://url.com | Abierta | No | Alta |
```

---

## Notas importantes

- **Nunca inventar fechas ni importes.** Si no se encuentran, poner "Por confirmar" o "—".
- **Siempre verificar** que la convocatoria esté realmente abierta antes de marcarla como "Abierta".
- **Priorizar fuentes oficiales** sobre agregadores (mejor la web del festival o programa que FilmFreeway o Festhome para datos de fechas).
- Si hay dudas sobre si una convocatoria ya está en el Excel de Lupe, mencionarlo para que ella verifique.
- Presentar primero las de mayor prioridad o deadline más próximo.
