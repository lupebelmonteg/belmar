# Config schema — full reference

The script `scripts/build_presupuesto.py` reads a JSON file with the shape below. Anything in `DEFAULTS` (inside the script) can be overridden by adding the same key in the config. Keys you don't touch are filled in automatically.

For most projects you only need to provide the **required** sections (client, creative, details, pricing, closing_message, output_path). Brand identity, contact info, team, and notes will use the BELMAR defaults.

## Top-level structure

```jsonc
{
  // REQUIRED
  "output_path": "/absolute/path/to/Presu CLIENTE.pdf",

  "client": { ... },        // cover page text
  "creative": { ... },      // page 3 — concepto + pilares
  "details": { ... },       // page 4 — equipo, entregables, calendario
  "pricing": { ... },       // page 5 — tabla + incluido/no incluido
  "closing_message": "…",   // page 7 — mensaje de cierre

  // OPTIONAL — only set to override a default
  "pdf_title": "Presupuesto BELMAR",
  "colors": { ... },
  "brand": { ... },
  "contact": { ... },
  "about": { ... },
  "team": { ... },
  "notes": { ... }
}
```

## `client` — cover

```jsonc
"client": {
  "project_title_line1": "PROPUESTA",       // first line, sans regular
  "project_title_line2": "AUDIOVISUAL",     // second line, sans bold, accent color
  "subtitle": "Cliente  ×  Proyecto"        // small grey line under the title
}
```

The cover always shows BELMAR + tagline at the bottom and the year top-right. To change the year for a specific project, set `brand.year`.

## `creative` — propuesta creativa (page 3)

```jsonc
"creative": {
  "headline_line1": "Concepto en una línea,",       // serif regular
  "headline_line2": "remate evocador.",             // serif italic, accent color
  "paragraphs": [                                   // 2–4 paragraphs of body copy
    "Párrafo 1...",
    "Párrafo 2..."
  ],
  "pillars": [                                       // 3–4 columns at the bottom
    {"title": "HUMANO", "body": "Línea 1.\nLínea 2.\nLínea 3."},
    {"title": "CERCANO", "body": "..."},
    {"title": "CINE", "body": "..."},
    {"title": "LUJO", "body": "..."}
  ]
}
```

Pillar bodies use `\n` for line breaks (not real newlines in JSON, the literal `\n` characters which JSON parses to newlines).

## `details` — qué incluye (page 4)

```jsonc
"details": {
  "section_title": "QUÉ INCLUYE LA COBERTURA",
  "equipo_label": "EQUIPO POR JORNADA",
  "equipo": [
    "Dirección y dirección de fotografía — Lupe Belmonte",
    "Operador de cámara secundaria",
    "Fotografía editorial"
  ],
  "entregables_label": "ENTREGABLES POR EVENTO",
  "entregables": [
    "Vídeo principal de 2–3 minutos en horizontal",
    "1–2 reels verticales para redes",
    "30–40 fotos editadas en color y B/N"
  ],
  "calendario_label": "CALENDARIO DE RODAJES",
  "calendario": [
    {"label": "Concierto 01", "date": "Sábado · 23 de mayo de 2026"},
    {"label": "Concierto 02", "date": "Sábado · 27 de junio de 2026"}
  ],
  "delivery_note": "Entrega de cada pieza en un máximo de 2 semanas tras el rodaje.",
  "inspiration": "Inspiración estética: La Blogothèque y los registros íntimos del cine documental musical."
}
```

`delivery_note` and `inspiration` are optional. If `inspiration` is set, it renders as italic text at the bottom of the page with a horizontal rule above it.

## `pricing` — inversión (page 5)

```jsonc
"pricing": {
  "intro": "Párrafo introductorio que contextualiza el precio...",
  "table_header": ["CONCIERTO", "FECHA", "INVERSIÓN"],   // 2 or 3 columns
  "rows": [
    ["01", "23 de mayo de 2026", "3.250 €"],
    ["02", "27 de junio de 2026", "3.250 €"],
    ["03", "25 de julio de 2026", "3.250 €"]
  ],
  "total_label": "TOTAL",
  "total_value": "9.750 € + IVA",
  "incluido": [
    "Equipo técnico completo",
    "Postproducción de vídeo y foto",
    "Entrega en hasta 2 semanas"
  ],
  "no_incluido": [
    "Transporte fuera de Madrid",
    "Derechos musicales",
    "Permisos de rodaje"
  ]
}
```

The table layout adapts: 2 columns gives 110 mm + 50 mm; 3 columns gives 35 + 75 + 50 mm; otherwise even split. The last row is automatically rendered as the total (accent background, accent text).

## `closing_message` — page 7

```jsonc
"closing_message": "Estamos entusiasmados con la posibilidad de acompañar a Cliente en este proyecto. Sería un privilegio prestar nuestra mirada a lo que estáis construyendo."
```

A short italic paragraph rendered centered under the BELMAR logotype.

## Overrides

### `colors`
```jsonc
"colors": {
  "accent": "#1E3A5F",       // navy — used for accent lines, italic headlines, total row
  "accent_bg": "#F1F4F8",    // pale tint for total row background
  "dark": "#1A1A1A",         // body text
  "grey": "#5A5A5A",         // secondary text
  "light_grey": "#9A9A9A"    // tertiary, hairlines
}
```

### `brand`
```jsonc
"brand": {
  "name": "BELMAR",
  "tagline": "where cinema meets brand identity",
  "founder": "Founded by Lupe Belmonte",
  "year": "2026"
}
```

### `contact`
```jsonc
"contact": {
  "name": "Lupe Belmonte",
  "phone": "+34 638 09 20 42",
  "email": "lupebelmonteg@gmail.com",
  "address": "C/ Fernandez de la Hoz 1, Madrid",
  "social_left": "Instagram  ·  YouTube",
  "social_right": "LinkedIn  ·  IMDB",
  "handle": "@_lupebelmonte"
}
```

### `about` and `team`
The BELMAR boilerplate. Override `about.paragraphs` if a specific project needs a different elevator pitch (e.g., emphasizing a specific brand list relevant to that client). Override `team.members` to add or hide collaborators per project.

```jsonc
"about": {
  "section_label": "QUIÉNES SOMOS",
  "paragraphs": ["Párrafo 1", "Párrafo 2", "Párrafo 3"],
  "quote": "“Frase entre comillas tipográficas.”"
},
"team": {
  "section_label": "EL EQUIPO",
  "members": [
    ["Nombre", "Rol"],
    ...
  ]
}
```

### `notes`
The "Notas adicionales" page (page 6). The default has 7 blocks (plazos, pago, cliente, transporte, derechos, fuerza mayor, validez). Override to add, remove, or rephrase.

```jsonc
"notes": {
  "section_label": "NOTAS ADICIONALES",
  "blocks": [
    ["TÍTULO EN MAYÚSCULAS", "Cuerpo del bloque, puede usar <b>negritas</b>."],
    ...
  ]
}
```

## Tips

- Use Spanish typographic quotes `“ ”` and `«»`, not `"`.
- For thousands separators in prices use `.` (Spanish convention): `9.750 €`.
- Use `<b>...</b>` inside paragraphs for bold (Reportlab Paragraph supports inline HTML).
- Italic inside paragraphs: `<i>...</i>`.
- Don't use `<br/>` — instead, split into separate paragraph entries.
- Pillar bodies are the exception: there `\n` does create real line breaks (rendered manually, not via Paragraph).
