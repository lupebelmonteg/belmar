# BELMAR — Guía de voz

Read this before writing creative copy for any presupuesto. Lupe's clients read this stuff carefully — the words have to feel cinematic, premium, and personal at the same time.

## La fórmula BELMAR

Dos mundos que casi nadie combina:

1. **Cine de autor / documental** — Lupe viene del cine independiente (HBO, Movistar+, Sorrentino, Zanussi). Ahí aprendió a mirar a las personas, a esperar el gesto que no se planea, a iluminar como un fotograma de película.
2. **Lujo editorial / marca** — BELMAR ha trabajado con Estée Lauder, Rituals, El Ganso, Iberdrola, Forbes, Casa Decor. Sabe que una marca premium no quiere "contenido", quiere una pieza que sostenga su universo.

**Para cada propuesta, la pregunta es: ¿por qué este cliente concreto necesita justo esa combinación?** Esa es la frase de apertura del concepto, no un genérico "somos un equipo creativo".

Ejemplos:
- Concierto íntimo sin móviles → necesitan que alguien con mirada documental capture lo efímero, pero con calidad de fashion film para que la pieza sostenga la marca del festival.
- Campaña de cosmética → necesitan textura cinematográfica (no spot publicitario al uso) para conectar con la sensorialidad del producto.
- Boda de alta gama → necesitan que la pareja sea protagonista de su propia película, no de un reportaje al uso.

## Vocabulario que sí

- **mirada** (no "estilo" ni "look")
- **narrativa** (no "historia" a secas)
- **filmar / tomar / registrar** (no "grabar" en headlines)
- **sensibilidad, textura, atmósfera, gesto, silencio**
- **pieza** (para referirse al vídeo final, en lugar de "vídeo" o "contenido")
- **cinematográfico, editorial, íntimo, contenido**
- **acompañar al cliente / estar al lado / leer el momento**

## Vocabulario que no

- "Branding", "session", "feedback", "deliverables", "brief" → traducir o reformular
- "Contenido para redes" sin más → al menos "piezas que respiran en el feed"
- "Equipo profesional" → vacío, todos lo dicen
- "Calidad", "excelencia" → palabras gastadas, mostrar en lugar de afirmar
- "Disfrutar el momento", "vivencia única" → suenan a folleto turístico

## Estructura del concepto creativo

Los párrafos centrales (campo `creative.paragraphs` en el config) deberían leerse como una **column de revista**, no como bullets. Plantilla mental:

1. **Párrafo 1 — el insight.** Qué hace especial a este encargo concreto. Una observación, no un pitch.
2. **Párrafo 2 — el approach.** Cómo lo abordaríamos. Cómo se vería el rodaje, qué tipo de planos buscaríamos, qué dejaríamos pasar.
3. **Párrafo 3 — el resultado.** Qué le queda al cliente cuando termine. Una pieza para X usos, una memoria para Y momentos, un activo para Z campañas.
4. **Párrafo 4 (opcional) — el porqué BELMAR.** Por qué este equipo concreto encaja con esta marca concreta. Aquí es donde se citan referencias o se conecta con trabajos anteriores.

Cada párrafo: **3 a 5 frases**. Frases medias, ritmo respirado. Si una frase pasa de tres líneas en pantalla, romperla.

## Los pilares (4 columnas en propuesta creativa)

Al final de la propuesta creativa van **cuatro pilares** en columnas. Cada uno: un sustantivo en mayúscula + tres líneas de prosa breve.

Plantilla recomendada:
- **HUMANO** — la dimensión documental, las personas, lo que no se planea.
- **CERCANO** — cómo se trabaja en rodaje, cómo se trata al cliente y al protagonista.
- **CINE** — la calidad técnica y estética, los referentes, la formación.
- **LUJO** — la presencia editorial, la marca, las campañas previas.

No siempre tiene que ser exactamente esos cuatro. Si el proyecto es muy técnico se puede sustituir LUJO por OFICIO, o si es muy social cambiar CERCANO por COMUNIDAD. Pero el patrón "humano + ejecución + cine + marca" debería estar ahí en alguna forma.

## Tono general

- **Premium pero cálido.** Nunca corporativo, nunca distante. Lupe es cercana en persona, sus presupuestos también.
- **Confianza sin autobombo.** Las credenciales (Sorrentino, Zanussi, HBO, marcas) se mencionan una vez, no se repiten. El trabajo habla.
- **Español de España.** "Vosotros", "rodaje", "mañana en", "vale", "guay" no — "encantados", "acompañar", "trabajar codo con codo" sí.
- **Sin emoji ni signos de admiración.** Nunca.
- **Negritas para los nombres propios** (marcas, personas) y para una o dos frases-clave por sección. Nada más.

## El cierre

La página de cierre lleva un mensaje breve (campo `closing_message`). Ese mensaje debe:
- Empezar con "Estamos entusiasmados" o "Sería un privilegio" o similar — gratitud genuina, no rutinaria.
- Mencionar el nombre del cliente y/o del proyecto.
- Cerrar con una frase corta sobre lo que significaría hacerlo juntos.
- Máximo 3 líneas.

Ejemplo: "Estamos entusiasmados con la posibilidad de acompañar a Conciertos Sin Cobertura en este capítulo. Sería un privilegio prestar nuestra mirada al trabajo que estáis construyendo."

## Cómo elegir las marcas a citar

BELMAR tiene un roster amplio. Citar **4 a 6 marcas máximo** por propuesta, elegidas por afinidad con el cliente:

- **Lujo / cosmética / moda** → Estée Lauder, Rituals, El Ganso, Casa Decor
- **Cultura / instituciones** → Museo del Prado, Fundación A LA PAR, Forbes
- **Corporate / consultoría** → BCG, IBM, American Express, Iberdrola
- **Gastronomía** (si la lista se amplía) → Berasategui, Pepe Rodríguez
- **Eventos / festivales** → mezcla equilibrada de cultura y marca

No listar nunca todo. La sobreabundancia mata el lujo.
