---
name: belmar-presupuesto
description: Generate a professional BELMAR (Lupe Belmonte) PDF budget proposal in her signature luxury editorial style — navy editorial blue accent, serif logo, generous line spacing, and the standard structure she uses for premium clients. Use this skill ANY time Lupe asks to create, draft, or prepare a "presupuesto", "propuesta", "budget", or "cotización" for a client of BELMAR, even if she just describes a client and price without explicitly asking for a PDF. Also trigger when she mentions a new audiovisual project (rodaje, conciertos, evento, contenido para marca, sesión fotográfica, fashion film, video corporativo) and wants to send something formal to the client.
---

# BELMAR — Presupuesto Generator

This skill creates a multi-page PDF budget proposal in BELMAR's luxury editorial style for Lupe Belmonte's clients.

## When to use this skill

- The user (Lupe) asks for a "presupuesto", "propuesta", "budget", or "cotización"
- She names a client and what they're asking for, even casually
- She mentions a new project for a brand and wants to formalize the offer
- She wants to revise an existing BELMAR proposal and asks for the editable version

This skill is **only** for BELMAR (the premium / luxury brand). For her simpler / non-luxury budgets (signed as "Lupe Belmonte" with the teal accent line), don't use this skill — those are handled in Canva directly.

## How it works

1. **Gather the project info** by asking targeted questions (see "Intake checklist" below).
2. **Write a `config.json`** with all the per-project content.
3. **Run `scripts/build_presupuesto.py`** pointing at the config.
4. **Show the resulting PDF** to Lupe and offer to refine.

## Intake checklist

Before writing the config, make sure you have these answers. If any are missing, ask Lupe with a short, focused question — don't pile on. She prefers to be asked in small batches.

**Project basics**
- Cliente (brand/agency name) and proyecto (campaign/event name) — these go in the cover
- Fechas (rodaje + entrega)
- Ubicación (Madrid o fuera — afecta la nota de dietas)

**Servicio**
- Equipo: cuántas cámaras de vídeo, cuántas de foto, dron, otros
- Entregables: vídeo principal (duración, horizontal/vertical), reels, fotos editadas (cuántas), formato
- Algo especial (sonido directo, voice over, modelo, vestuario)

**Precio**
- Total final (con o sin IVA explícito) y desglose si hay varias jornadas/eventos
- Qué NO está incluido (transporte, derechos musicales, permisos, dietas)

**Ángulo creativo (lo más importante para el lujo)**
- ¿Cuál es el "concepto" o gancho creativo? (ej: "registrar lo que no puede grabarse" para el cliente sin móvil)
- ¿Qué referencias estéticas? (ej: La Blogothèque, fashion film, documental íntimo)
- ¿Qué hace a BELMAR la opción correcta para este cliente concreto?

If she gives you a thin brief, propose a concept yourself and ask her to confirm/edit — don't just copy her words.

## Voice and style

Read `references/voice_guide.md` before writing the creative copy. The BELMAR voice is:
- **Premium but warm** — not cold corporate-speak
- **Cinematic vocabulary** — "mirada", "narrativa", "tomar", "filmar", "sensibilidad"
- **Confident credentials** — name-drop HBO, Movistar+, Sorrentino, Zanussi, plus the relevant brand list (Iberdrola, Estée Lauder, El Ganso, Forbes, Rituals, etc.)
- **Short, declarative sentences** in headlines; longer rhythmic prose in body
- **Spanish from Spain** (not Latin American)

The signature move BELMAR makes: combine **the human/documentary side** (Lupe's auteur cinema background) with **the editorial luxury side** (brand campaigns). For every project, find why this combination matters here and lead with it.

## Building the config

The script reads a JSON file with this top-level shape (see `examples/conciertos_sin_cobertura.json` for a complete worked example):

```json
{
  "output_path": "/absolute/path/to/Presu CLIENTE.pdf",
  "client": {
    "project_title_line1": "PROPUESTA",
    "project_title_line2": "AUDIOVISUAL",
    "subtitle": "Cliente  ×  Proyecto"
  },
  "creative": {
    "headline_line1": "Concepto en una línea,",
    "headline_line2": "remate evocador.",
    "paragraphs": ["...", "...", "...", "..."],
    "pillars": [
      {"title": "HUMANO", "body": "Línea 1.\nLínea 2.\nLínea 3."},
      {"title": "...", "body": "..."},
      {"title": "...", "body": "..."},
      {"title": "...", "body": "..."}
    ]
  },
  "details": {
    "section_title": "QUÉ INCLUYE LA COBERTURA",
    "equipo_label": "EQUIPO POR ...",
    "equipo": ["item1", "item2"],
    "entregables_label": "ENTREGABLES POR ...",
    "entregables": ["item1", "item2"],
    "calendario_label": "CALENDARIO DE RODAJES",
    "calendario": [
      {"label": "Concierto 01", "date": "Sábado · 23 de mayo de 2026"}
    ],
    "delivery_note": "Entrega ...",
    "inspiration": "Inspiración estética: ..."
  },
  "pricing": {
    "intro": "Párrafo introductorio...",
    "table_header": ["CONCIERTO", "FECHA", "INVERSIÓN"],
    "rows": [
      ["01", "23 de mayo de 2026", "3.250 €"]
    ],
    "total_label": "TOTAL",
    "total_value": "9.750 € + IVA",
    "incluido": ["item", "item"],
    "no_incluido": ["item", "item"]
  },
  "notes_overrides": {},
  "closing_message": "Estamos entusiasmados con la posibilidad de acompañar a ..."
}
```

**Defaults baked into the script** (no need to repeat in JSON):
- Brand identity (BELMAR, "where cinema meets brand identity")
- Contact info (Lupe Belmonte, +34 638 09 20 42, lupebelmonteg@gmail.com, C/ Fernandez de la Hoz 1, Madrid)
- Equipo list (Lupe, Patricio SJ, Iguacel Barceló, Marina Martín, Alex Moreno, Margarita Diez)
- Quote ("Sabemos escuchar lo íntimo y filmarlo con la elegancia del cine.")
- Standard "Notas adicionales" (plazos, pago 50/50, derechos, fuerza mayor, validez 30 días)
- Brand colors (navy #1E3A5F, dark text, light grey)

Override any default by adding the corresponding key to the config (`brand`, `team`, `notes_overrides`, `colors`, etc.). See `references/config_schema.md` for the full list of overridable fields.

## Workflow

1. Read `references/voice_guide.md` for tone calibration.
2. Talk to Lupe; collect the intake info. Propose creative angle if she didn't give one.
3. Write the config JSON to a temp path next to where the PDF will go.
4. Run:
   ```bash
   python3 <skill-path>/scripts/build_presupuesto.py --config <path-to-config.json>
   ```
5. Show Lupe the PDF with a `computer://` link.
6. **Critique your own output.** List the things you assumed without confirming, the things that are missing (logos, photos, exact figures), and any wording that could read flat. Don't wait for her to find them.
7. Iterate based on her feedback (color, spacing, pricing, copy). Re-run the script.

## Common pitfalls to avoid

- **Don't over-format** the creative paragraphs. They should read like editorial copy, not bullet points. Use prose, two to four short paragraphs.
- **Don't list the entire client roster** every time. Pick 4–6 brands relevant to the proposal's tier and tone (luxury beauty → Estée Lauder, Rituals; gastronomy → Berasategui, Pepe Rodríguez; fashion → El Ganso, Springfield; corporate → BCG, Iberdrola, IBM).
- **Don't fabricate numbers or dates** — if Lupe didn't give you a date or a specific count, ask. Don't invent "30–40 fotos" or "2 reels" without confirming.
- **Don't write Englishisms** ("session", "feedback", "branding") in body copy — translate or rephrase. "Estilo sesión" instead of "estilo session", etc.
- **Always offer a Word/Canva-friendly alternative** at the end — Lupe sometimes wants to take the copy back to Canva to redesign.
