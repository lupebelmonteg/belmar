"""
BELMAR — Presupuesto generator
Reads a JSON config and produces a multi-page PDF in BELMAR's luxury editorial style.

Usage:
    python3 build_presupuesto.py --config /path/to/config.json
"""

import argparse
import json
import sys
from pathlib import Path

from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.pdfgen import canvas
from reportlab.platypus import Paragraph, Table, TableStyle
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_JUSTIFY


# =================================================================
# DEFAULTS — BELMAR brand identity
# =================================================================
DEFAULTS = {
    "colors": {
        "accent": "#1E3A5F",
        "accent_bg": "#F1F4F8",
        "dark": "#1A1A1A",
        "grey": "#5A5A5A",
        "light_grey": "#9A9A9A",
    },
    "brand": {
        "name": "BELMAR",
        "tagline": "where cinema meets brand identity",
        "founder": "Founded by Lupe Belmonte",
        "year": "2026",
    },
    "contact": {
        "name": "Lupe Belmonte",
        "phone": "+34 638 09 20 42",
        "email": "lupebelmonteg@gmail.com",
        "address": "C/ Fernandez de la Hoz 1, Madrid",
        "social_left": "Instagram  ·  YouTube",
        "social_right": "LinkedIn  ·  IMDB",
        "handle": "@_lupebelmonte",
    },
    "about": {
        "section_label": "QUIÉNES SOMOS",
        "paragraphs": [
            ("BELMAR nace de la mirada de <b>Lupe Belmonte</b>, cineasta especializada "
             "en historias humanas y narrativas con fuerte carga estética. Ha trabajado en "
             "películas y series de <b>HBO, Movistar+ y A Contracorriente</b>, y ha tenido el "
             "privilegio de formarse junto a <b>Krzysztof Zanussi y Paolo Sorrentino</b>, "
             "grandes maestros del cine."),
            ("En BELMAR trasladamos la sensibilidad del cine documental a la publicidad y "
             "el contenido cultural, trabajando con marcas y artistas que buscan algo más "
             "que un buen vídeo: buscan <b>una mirada</b>."),
            ("Hemos desarrollado proyectos para <b>Iberdrola, Estée Lauder, El Ganso, Forbes, "
             "Rituals, Civitatis, BCG, American Express, Casa Decor, Museo del Prado y la "
             "Fundación A LA PAR</b>, entre otros."),
        ],
        "quote": "“Sabemos escuchar lo íntimo y filmarlo con la elegancia del cine.”",
    },
    "team": {
        "section_label": "EL EQUIPO",
        "members": [
            ("Lupe Belmonte", "Dirección y dirección de fotografía"),
            ("Patricio SJ", "Guion"),
            ("Iguacel Barceló", "Edición y postproducción"),
            ("Marina Martín", "Fotografía"),
            ("Alex Moreno", "Producción y dron certificado"),
            ("Margarita Diez", "Dirección de arte"),
        ],
    },
    "notes": {
        "section_label": "NOTAS ADICIONALES",
        "blocks": [
            ("PLAZOS DE ENTREGA",
             "El material editado se entregará en un plazo máximo de <b>2 semanas</b> tras el "
             "rodaje, con una semana adicional para rondas de revisión. Se incluyen hasta dos "
             "rondas de revisión; a partir de la tercera se aplicará una tarifa de 100 € por "
             "jornada de edición."),
            ("FORMA DE PAGO",
             "El pago se realiza en dos fases: <b>50% al inicio</b> del proyecto (reserva de "
             "fechas) y <b>50% a la entrega final</b>. Todos los pagos deberán efectuarse "
             "dentro de los 15 días hábiles posteriores a la emisión de la factura."),
            ("CLIENTE",
             "El cliente proporcionará el material gráfico necesario (logotipos, referencias) "
             "y asegurará contar con los derechos de imagen y los derechos musicales "
             "correspondientes."),
            ("TRANSPORTE Y DIETAS",
             "Dietas y desplazamientos fuera de la Comunidad de Madrid correrán a cargo del "
             "cliente."),
            ("DERECHOS Y PROPIEDAD",
             "El cliente tendrá todos los derechos de uso y distribución del material final. "
             "BELMAR y su equipo se reservan el derecho de incluir fragmentos en su "
             "portfolio, redes y materiales de presentación."),
            ("FUERZA MAYOR",
             "BELMAR no será responsable de retrasos o incumplimientos causados por "
             "circunstancias fuera de su control (desastres naturales, pandemias, actos "
             "gubernamentales, cancelaciones del evento, etc.)."),
            ("VALIDEZ",
             "Este presupuesto tiene una validez de <b>30 días</b> desde su emisión."),
        ],
    },
}


# =================================================================
# Layout constants
# =================================================================
PAGE_W, PAGE_H = A4
MARGIN_L = 22 * mm
MARGIN_R = 22 * mm
MARGIN_T = 22 * mm
MARGIN_B = 22 * mm

SERIF = "Times-Roman"
SERIF_B = "Times-Bold"
SERIF_I = "Times-Italic"
SANS = "Helvetica"
SANS_B = "Helvetica-Bold"


def deep_merge(base, override):
    """Recursively merge override into base, returning a new dict."""
    if not isinstance(base, dict) or not isinstance(override, dict):
        return override if override is not None else base
    result = dict(base)
    for k, v in override.items():
        if k in result and isinstance(result[k], dict) and isinstance(v, dict):
            result[k] = deep_merge(result[k], v)
        else:
            result[k] = v
    return result


def build(config):
    cfg = deep_merge(DEFAULTS, config)

    # Resolve colors
    ACCENT = colors.HexColor(cfg["colors"]["accent"])
    ACCENT_BG = colors.HexColor(cfg["colors"]["accent_bg"])
    DARK = colors.HexColor(cfg["colors"]["dark"])
    GREY = colors.HexColor(cfg["colors"]["grey"])
    LIGHT_GREY = colors.HexColor(cfg["colors"]["light_grey"])

    output = cfg["output_path"]
    Path(output).parent.mkdir(parents=True, exist_ok=True)

    c = canvas.Canvas(output, pagesize=A4)
    c.setTitle(cfg.get("pdf_title", "Presupuesto BELMAR"))
    c.setAuthor(f"{cfg['contact']['name']} - {cfg['brand']['name']}")

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------
    def inner_header():
        c.setFont(SERIF_B, 11)
        c.setFillColor(DARK)
        c.drawString(MARGIN_L, PAGE_H - MARGIN_T + 4, cfg["brand"]["name"])
        c.setStrokeColor(ACCENT)
        c.setLineWidth(0.8)
        c.line(MARGIN_L + 35 * mm, PAGE_H - MARGIN_T + 7,
               PAGE_W - MARGIN_R, PAGE_H - MARGIN_T + 7)

    def inner_footer(page_label):
        c.setFont(SANS, 8)
        c.setFillColor(GREY)
        contact_line = (f"{cfg['contact']['name']}  ·  {cfg['contact']['phone']}  ·  "
                        f"{cfg['contact']['email']}  ·  {cfg['contact']['address']}")
        c.drawString(MARGIN_L, MARGIN_B - 10, contact_line)
        c.setStrokeColor(ACCENT)
        c.setLineWidth(0.8)
        c.line(MARGIN_L, MARGIN_B - 4, PAGE_W - MARGIN_R - 15 * mm, MARGIN_B - 4)
        c.setFont(SANS_B, 9)
        c.setFillColor(DARK)
        c.drawRightString(PAGE_W - MARGIN_R, MARGIN_B - 4, page_label)

    def section_heading(y, num, title):
        c.setFont(SANS, 11)
        c.setFillColor(LIGHT_GREY)
        c.drawString(MARGIN_L, y, num)
        c.setFont(SANS_B, 22)
        c.setFillColor(DARK)
        c.drawString(MARGIN_L + 18, y, title)
        c.setStrokeColor(ACCENT)
        c.setLineWidth(1.2)
        c.line(MARGIN_L, y - 8, MARGIN_L + 50 * mm, y - 8)

    # ------------------------------------------------------------------
    # PAGE 1 — COVER
    # ------------------------------------------------------------------
    cli = cfg["client"]
    c.setStrokeColor(ACCENT)
    c.setLineWidth(1.2)
    c.line(MARGIN_L, PAGE_H - MARGIN_T - 5, MARGIN_L + 55 * mm, PAGE_H - MARGIN_T - 5)
    c.setFont(SANS, 14)
    c.setFillColor(DARK)
    c.drawRightString(PAGE_W - MARGIN_R, PAGE_H - MARGIN_T - 2, cfg["brand"]["year"])

    c.setFillColor(ACCENT)
    c.rect(MARGIN_L, PAGE_H / 2 + 5, 2.5, 80, fill=1, stroke=0)

    title_y = PAGE_H / 2 + 60
    title1 = cli.get("project_title_line1", "PROPUESTA")
    title2 = cli.get("project_title_line2", "AUDIOVISUAL")

    # Auto-fit each title line to the available width
    title_x = MARGIN_L + 12
    avail_w = (PAGE_W - MARGIN_R) - title_x - 4

    title1_size = 44
    while c.stringWidth(title1, SANS, title1_size) > avail_w and title1_size > 22:
        title1_size -= 1
    c.setFont(SANS, title1_size)
    c.setFillColor(DARK)
    c.drawString(title_x, title_y, title1)

    title2_size = 56
    while c.stringWidth(title2, SANS_B, title2_size) > avail_w and title2_size > 26:
        title2_size -= 1
    c.setFont(SANS_B, title2_size)
    c.setFillColor(ACCENT)
    c.drawString(title_x, title_y - 55, title2)

    c.setFont(SANS, 13)
    c.setFillColor(GREY)
    c.drawString(title_x, title_y - 80, cli.get("subtitle", ""))

    c.setFont(SERIF_B, 18)
    c.setFillColor(DARK)
    c.drawString(MARGIN_L, MARGIN_B + 25, cfg["brand"]["name"])
    c.setFont(SERIF_I, 10)
    c.setFillColor(GREY)
    c.drawString(MARGIN_L, MARGIN_B + 12, cfg["brand"]["tagline"])

    c.setStrokeColor(ACCENT)
    c.setLineWidth(1.2)
    c.line(PAGE_W - MARGIN_R - 55 * mm, MARGIN_B + 18, PAGE_W - MARGIN_R, MARGIN_B + 18)
    c.showPage()

    # ------------------------------------------------------------------
    # Page / section counters (so we can skip optional pages)
    # ------------------------------------------------------------------
    show_about = cfg.get("pages", {}).get("about", True)
    page_num = 2  # cover was page 1
    section_num = 1

    def page_label():
        return f"{page_num:02d}"

    def section_label():
        return f"{section_num:02d}"

    styles = getSampleStyleSheet()
    fw = PAGE_W - MARGIN_L - MARGIN_R

    # ------------------------------------------------------------------
    # PAGE 2 (optional) — QUIÉNES SOMOS
    # ------------------------------------------------------------------
    if show_about:
        inner_header()
        y = PAGE_H - MARGIN_T - 25
        section_heading(y, section_label(), cfg["about"]["section_label"])

        body_style = ParagraphStyle("body", parent=styles["Normal"],
                                    fontName=SANS, fontSize=11, leading=21,
                                    textColor=DARK, alignment=TA_JUSTIFY)
        quote_style = ParagraphStyle("quote", parent=styles["Normal"],
                                     fontName=SERIF_I, fontSize=14, leading=24,
                                     textColor=ACCENT, alignment=TA_LEFT, leftIndent=10)

        cur_y = y - 32
        for txt in cfg["about"]["paragraphs"]:
            p = Paragraph(txt, body_style)
            w, h = p.wrap(fw, 200)
            cur_y -= h
            p.drawOn(c, MARGIN_L, cur_y)
            cur_y -= 20

        cur_y -= 14
        c.setStrokeColor(ACCENT)
        c.setLineWidth(2)
        c.line(MARGIN_L, cur_y + 12, MARGIN_L, cur_y - 30)
        pq = Paragraph(cfg["about"]["quote"], quote_style)
        w, h = pq.wrap(fw - 20, 60)
        pq.drawOn(c, MARGIN_L + 12, cur_y - 22)
        cur_y -= 60

        cur_y -= 18
        c.setFont(SANS_B, 13)
        c.setFillColor(DARK)
        c.drawString(MARGIN_L, cur_y, cfg["team"]["section_label"])
        c.setStrokeColor(ACCENT)
        c.setLineWidth(0.8)
        c.line(MARGIN_L, cur_y - 5, MARGIN_L + 28 * mm, cur_y - 5)
        cur_y -= 28

        for name, role in cfg["team"]["members"]:
            c.setFont(SANS_B, 10.5)
            c.setFillColor(DARK)
            c.drawString(MARGIN_L, cur_y, name)
            c.setFont(SANS, 10.5)
            c.setFillColor(GREY)
            c.drawString(MARGIN_L + 50 * mm, cur_y, role)
            cur_y -= 20

        inner_footer(page_label())
        c.showPage()
        page_num += 1
        section_num += 1

    # ------------------------------------------------------------------
    # PROPUESTA CREATIVA
    # ------------------------------------------------------------------
    inner_header()
    y = PAGE_H - MARGIN_T - 25
    section_heading(y, section_label(), "PROPUESTA CREATIVA")

    creative = cfg["creative"]
    cur_y = y - 50
    c.setFont(SERIF, 28)
    c.setFillColor(DARK)
    c.drawString(MARGIN_L, cur_y, creative.get("headline_line1", ""))
    c.setFont(SERIF_I, 28)
    c.setFillColor(ACCENT)
    c.drawString(MARGIN_L, cur_y - 32, creative.get("headline_line2", ""))

    cur_y -= 70
    body_style = ParagraphStyle("body2", parent=styles["Normal"],
                                fontName=SANS, fontSize=11, leading=21,
                                textColor=DARK, alignment=TA_JUSTIFY)
    for txt in creative.get("paragraphs", []):
        p = Paragraph(txt, body_style)
        w, h = p.wrap(fw, 200)
        cur_y -= h
        p.drawOn(c, MARGIN_L, cur_y)
        cur_y -= 18

    pillars = creative.get("pillars", [])
    if pillars:
        cur_y -= 18
        c.setStrokeColor(ACCENT)
        c.setLineWidth(0.8)
        c.line(MARGIN_L, cur_y, PAGE_W - MARGIN_R, cur_y)
        cur_y -= 28

        col_w = (PAGE_W - MARGIN_L - MARGIN_R) / len(pillars)
        for i, pillar in enumerate(pillars):
            x = MARGIN_L + i * col_w
            c.setFont(SANS_B, 11)
            c.setFillColor(ACCENT)
            c.drawString(x, cur_y, pillar["title"])
            c.setFont(SANS, 9.5)
            c.setFillColor(DARK)
            for j, line in enumerate(pillar["body"].split("\n")):
                c.drawString(x, cur_y - 18 - j * 14, line)

    inner_footer(page_label())
    c.showPage()
    page_num += 1
    section_num += 1

    # ------------------------------------------------------------------
    # DETALLES
    # ------------------------------------------------------------------
    inner_header()
    y = PAGE_H - MARGIN_T - 25
    details = cfg["details"]
    section_heading(y, section_label(), details.get("section_title", "QUÉ INCLUYE"))

    cur_y = y - 45

    def render_list(label, items, cur_y_local):
        c.setFont(SANS_B, 12)
        c.setFillColor(DARK)
        c.drawString(MARGIN_L, cur_y_local, label)
        cur_y_local -= 24
        c.setFont(SANS, 10.5)
        for it in items:
            c.setFillColor(ACCENT)
            c.drawString(MARGIN_L, cur_y_local, "—")
            c.setFillColor(DARK)
            c.drawString(MARGIN_L + 12, cur_y_local, it)
            cur_y_local -= 19
        return cur_y_local

    cur_y = render_list(details.get("equipo_label", "EQUIPO"),
                        details.get("equipo", []), cur_y)
    cur_y -= 16
    cur_y = render_list(details.get("entregables_label", "ENTREGABLES"),
                        details.get("entregables", []), cur_y)

    cur_y -= 16
    c.setFont(SANS_B, 12)
    c.setFillColor(DARK)
    c.drawString(MARGIN_L, cur_y, details.get("calendario_label", "CALENDARIO"))
    cur_y -= 24

    for entry in details.get("calendario", []):
        c.setFont(SANS_B, 11)
        c.setFillColor(ACCENT)
        c.drawString(MARGIN_L, cur_y, entry["label"])
        c.setFont(SANS, 11)
        c.setFillColor(DARK)
        c.drawString(MARGIN_L + 35 * mm, cur_y, entry["date"])
        c.setStrokeColor(LIGHT_GREY)
        c.setLineWidth(0.4)
        c.line(MARGIN_L, cur_y - 6, PAGE_W - MARGIN_R, cur_y - 6)
        cur_y -= 22

    if details.get("delivery_note"):
        cur_y -= 8
        c.setFont(SANS, 9.5)
        c.setFillColor(GREY)
        c.drawString(MARGIN_L, cur_y, details["delivery_note"])

    if details.get("inspiration"):
        cur_y -= 38
        c.setStrokeColor(ACCENT)
        c.setLineWidth(0.8)
        c.line(MARGIN_L, cur_y + 5, PAGE_W - MARGIN_R, cur_y + 5)
        cur_y -= 5
        ins_style = ParagraphStyle("ins", fontName=SERIF_I, fontSize=11,
                                   leading=20, textColor=DARK)
        p = Paragraph(f"<i>{details['inspiration']}</i>", ins_style)
        w, h = p.wrap(fw, 60)
        cur_y -= h
        p.drawOn(c, MARGIN_L, cur_y)

    inner_footer(page_label())
    c.showPage()
    page_num += 1
    section_num += 1

    # ------------------------------------------------------------------
    # INVERSIÓN
    # ------------------------------------------------------------------
    inner_header()
    y = PAGE_H - MARGIN_T - 25
    section_heading(y, section_label(), "INVERSIÓN")

    pricing = cfg["pricing"]
    cur_y = y - 45

    if pricing.get("intro"):
        intro_style = ParagraphStyle("intro", fontName=SANS, fontSize=11,
                                     leading=21, textColor=DARK, alignment=TA_JUSTIFY)
        p = Paragraph(pricing["intro"], intro_style)
        w, h = p.wrap(fw, 100)
        cur_y -= h
        p.drawOn(c, MARGIN_L, cur_y)
        cur_y -= 28

    # Support both legacy single-table and new "options" array
    if "options" in pricing:
        options = pricing["options"]
    else:
        options = [{
            "title": pricing.get("title"),
            "table_header": pricing.get("table_header", ["", "", ""]),
            "rows": pricing.get("rows", []),
            "total_label": pricing.get("total_label", "TOTAL"),
            "total_value": pricing.get("total_value", ""),
        }]

    # Tighter padding when stacking multiple option tables
    multi = len(options) > 1
    cell_pad = 9 if multi else 14
    title_size = 11

    for opt in options:
        if opt.get("title"):
            cur_y -= 4
            c.setFont(SANS_B, title_size)
            c.setFillColor(ACCENT)
            c.drawString(MARGIN_L, cur_y, opt["title"])
            c.setStrokeColor(ACCENT)
            c.setLineWidth(0.8)
            tw_title = c.stringWidth(opt["title"], SANS_B, title_size)
            c.line(MARGIN_L, cur_y - 4, MARGIN_L + tw_title, cur_y - 4)
            cur_y -= 16

        header = opt["table_header"]
        rows = opt["rows"]
        total_label = opt.get("total_label", "TOTAL")
        total_value = opt.get("total_value", "")

        data = [header] + [list(r) for r in rows] + [["", total_label, total_value]]
        n_cols = len(header)
        if n_cols == 3:
            col_widths = [35 * mm, 75 * mm, 50 * mm]
        elif n_cols == 2:
            col_widths = [110 * mm, 50 * mm]
        else:
            col_widths = [(PAGE_W - MARGIN_L - MARGIN_R) / n_cols] * n_cols

        table = Table(data, colWidths=col_widths)
        table.setStyle(TableStyle([
            ("FONT", (0, 0), (-1, 0), SANS_B, 10),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("BACKGROUND", (0, 0), (-1, 0), DARK),
            ("ALIGN", (0, 0), (-1, -1), "LEFT"),
            ("ALIGN", (-1, 0), (-1, -1), "RIGHT"),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ("BOTTOMPADDING", (0, 0), (-1, -1), cell_pad),
            ("TOPPADDING", (0, 0), (-1, -1), cell_pad),
            ("LEFTPADDING", (0, 0), (-1, -1), 12),
            ("RIGHTPADDING", (0, 0), (-1, -1), 12),
            ("FONT", (0, 1), (-1, -2), SANS, 11),
            ("TEXTCOLOR", (0, 1), (-1, -2), DARK),
            ("LINEBELOW", (0, 1), (-1, -2), 0.4, LIGHT_GREY),
            ("FONT", (0, -1), (-1, -1), SANS_B, 12 if multi else 13),
            ("TEXTCOLOR", (0, -1), (-1, -1), ACCENT),
            ("BACKGROUND", (0, -1), (-1, -1), ACCENT_BG),
            ("LINEABOVE", (0, -1), (-1, -1), 1.5, ACCENT),
        ]))
        tw, th = table.wrap(fw, 400)
        cur_y -= th
        table.drawOn(c, MARGIN_L, cur_y)
        cur_y -= 18 if multi else 30

    incluye = pricing.get("incluido", [])
    no_incluye = pricing.get("no_incluido", [])
    if incluye or no_incluye:
        cur_y -= 14
        half = (fw - 10) / 2
        c.setFont(SANS_B, 11)
        c.setFillColor(DARK)
        c.drawString(MARGIN_L, cur_y, "INCLUIDO")
        c.setStrokeColor(ACCENT)
        c.line(MARGIN_L, cur_y - 4, MARGIN_L + 22 * mm, cur_y - 4)
        c.drawString(MARGIN_L + half + 10, cur_y, "NO INCLUIDO")
        c.line(MARGIN_L + half + 10, cur_y - 4,
               MARGIN_L + half + 10 + 30 * mm, cur_y - 4)
        cur_y -= 22

        c.setFont(SANS, 10)
        n = max(len(incluye), len(no_incluye))
        for i in range(n):
            y_line = cur_y - i * 19
            if i < len(incluye):
                c.setFillColor(ACCENT); c.drawString(MARGIN_L, y_line, "—")
                c.setFillColor(DARK); c.drawString(MARGIN_L + 12, y_line, incluye[i])
            if i < len(no_incluye):
                c.setFillColor(LIGHT_GREY); c.drawString(MARGIN_L + half + 10, y_line, "—")
                c.setFillColor(GREY); c.drawString(MARGIN_L + half + 22, y_line, no_incluye[i])

    inner_footer(page_label())
    c.showPage()
    page_num += 1
    section_num += 1

    # ------------------------------------------------------------------
    # NOTAS ADICIONALES
    # ------------------------------------------------------------------
    inner_header()
    y = PAGE_H - MARGIN_T - 25
    section_heading(y, section_label(), cfg["notes"]["section_label"])

    h_style = ParagraphStyle("h", fontName=SANS_B, fontSize=11, leading=17,
                             textColor=ACCENT, spaceAfter=6)
    body_style = ParagraphStyle("body3", fontName=SANS, fontSize=10, leading=17,
                                textColor=DARK, spaceAfter=14, alignment=TA_JUSTIFY)

    cur_y = y - 40
    for h, b in cfg["notes"]["blocks"]:
        ph = Paragraph(h, h_style)
        wh, hh = ph.wrap(fw, 30)
        cur_y -= hh
        ph.drawOn(c, MARGIN_L, cur_y)
        pb = Paragraph(b, body_style)
        wb, hb = pb.wrap(fw, 200)
        cur_y -= hb + 6
        pb.drawOn(c, MARGIN_L, cur_y)
        cur_y -= 10

    inner_footer(page_label())
    c.showPage()
    page_num += 1
    section_num += 1

    # ------------------------------------------------------------------
    # CIERRE
    # ------------------------------------------------------------------
    c.setStrokeColor(ACCENT)
    c.setLineWidth(1.2)
    c.line(MARGIN_L, PAGE_H - MARGIN_T - 5, MARGIN_L + 55 * mm, PAGE_H - MARGIN_T - 5)
    c.setFont(SANS, 12)
    c.setFillColor(DARK)
    c.drawRightString(PAGE_W - MARGIN_R, PAGE_H - MARGIN_T - 2, cfg["brand"]["year"])

    cy = PAGE_H / 2 + 30
    c.setFont(SERIF_B, 38)
    c.setFillColor(DARK)
    c.drawCentredString(PAGE_W / 2, cy, cfg["brand"]["name"])
    c.setFont(SERIF_I, 14)
    c.setFillColor(GREY)
    c.drawCentredString(PAGE_W / 2, cy - 22, cfg["brand"]["tagline"])

    c.setStrokeColor(ACCENT)
    c.setLineWidth(1.5)
    c.line(PAGE_W / 2, cy - 50, PAGE_W / 2, cy - 95)

    c.setFont(SANS, 11)
    c.setFillColor(DARK)
    c.drawCentredString(PAGE_W / 2, cy - 120, cfg["brand"]["founder"])

    if cfg.get("closing_message"):
        msg_style = ParagraphStyle("msg", fontName=SERIF_I, fontSize=12,
                                   leading=22, textColor=DARK, alignment=TA_CENTER)
        msg = Paragraph(cfg["closing_message"], msg_style)
        w, h = msg.wrap(120 * mm, 200)
        # Anchor the TOP of the wrapped paragraph just below the founder line,
        # so longer messages grow downward instead of overlapping the founder.
        msg_top = cy - 145
        msg.drawOn(c, (PAGE_W - 120 * mm) / 2, msg_top - h)

    contact_y = MARGIN_B + 25
    c.setFont(SANS, 9.5)
    c.setFillColor(DARK)
    c.drawString(MARGIN_L, contact_y + 24, cfg["contact"]["email"])
    c.drawString(MARGIN_L, contact_y + 12, cfg["contact"]["phone"])
    c.drawString(MARGIN_L, contact_y, cfg["contact"]["address"])

    c.setFont(SANS, 9)
    c.setFillColor(GREY)
    c.drawRightString(PAGE_W - MARGIN_R, contact_y + 24, cfg["contact"]["social_left"])
    c.drawRightString(PAGE_W - MARGIN_R, contact_y + 12, cfg["contact"]["social_right"])
    c.drawRightString(PAGE_W - MARGIN_R, contact_y, cfg["contact"]["handle"])

    c.setStrokeColor(ACCENT)
    c.setLineWidth(1.2)
    c.line(MARGIN_L, MARGIN_B - 4, PAGE_W - MARGIN_R, MARGIN_B - 4)
    c.showPage()

    c.save()
    print(f"Saved: {output}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True, help="Path to config JSON")
    args = parser.parse_args()

    with open(args.config, "r", encoding="utf-8") as f:
        cfg = json.load(f)

    build(cfg)


if __name__ == "__main__":
    main()
